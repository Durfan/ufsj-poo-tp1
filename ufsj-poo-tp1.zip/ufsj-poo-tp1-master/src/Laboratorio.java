
public class Laboratorio {

}
