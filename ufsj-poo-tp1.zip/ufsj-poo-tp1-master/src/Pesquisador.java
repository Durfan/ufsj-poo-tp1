
public class Pesquisador extends  Colaboradores {

	
	private String nome;
	
	private Projeto projetos = new Projeto();

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Projeto getProjetos() {
		return projetos;
	}

	public void setProjetos(Projeto projetos) {
		this.projetos = projetos;
	}
	
	public String imprimir() {
		String conteudo = "Pesquisador: " + nome + "\n";
		return conteudo;
	}
	


}
